import sqlite3
from PyQt5.QtWidgets import QWidget, QApplication, QMainWindow
from PyQt5 import uic


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        uic.loadUi(io.StringIO('coffee.ui'), self)

    def show_coffee_info():
        con = sqlite3.connect('coffee.sqlite')
        cursor = con.cursor()
        req = "SELECT * FROM coffee"
        result = cursor.execute(req).fetchall()
        self.tableWidget.setText(result)
